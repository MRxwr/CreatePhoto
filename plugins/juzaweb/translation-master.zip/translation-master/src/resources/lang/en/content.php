<?php

return [
    'name' => 'Name',
    'translation' => 'Translation',
    'translations' => 'Translations',
];
