## About
The Movie plugin compliments your content by adding information about the movies, the television shows and the people in the industry you choose.

## Install
- Download cms: [https://juzaweb.com/download/](https://juzaweb.com/download/)
- Go to Admin -> Plugins -> Add new
- Search and add movie plugin
- Mymo theme: [https://juzaweb.com/theme/mymo](https://juzaweb.com/theme/mymo)

## Documentation
[https://juzaweb.com/plugin/movie/docs](https://juzaweb.com/plugin/movie/docs)